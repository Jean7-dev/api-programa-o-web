# ecommerce-back

## Instalação
```
npm install
```

## Execução
```
npm run dev
```

## Endpoints
- POST /api/customers
- GET /api/customers
- GET /api/customers/:id
- PUT /api/customers/:id
- DELETE /api/customers/:id
