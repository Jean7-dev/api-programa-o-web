const sqlite3 = require('sqlite3').verbose();
const { DB_FILE } = process.env;
const dbPath = DB_FILE || './database.sqlite';
const db = new sqlite3.Database(dbPath);
module.exports = db;