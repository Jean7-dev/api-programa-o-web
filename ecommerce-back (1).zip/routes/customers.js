const express = require('express');
const router = express.Router();
const db = require('../db');

router.post('/', (req, res) => {
  const { firstName, lastName, email, phone } = req.body;
  if (!firstName || !email) return res.status(400).json({ error: 'firstName e email são obrigatórios' });
  const sql = `INSERT INTO customers (firstName, lastName, email, phone) VALUES (?, ?, ?, ?)`;
  db.run(sql, [firstName, lastName || null, email, phone || null], function (err) {
    if (err) {
      if (err.message && err.message.includes('UNIQUE')) return res.status(409).json({ error: 'Email já cadastrado' });
      return res.status(500).json({ error: err.message });
    }
    db.get('SELECT * FROM customers WHERE id = ?', [this.lastID], (err2, row) => {
      if (err2) return res.status(500).json({ error: err2.message });
      res.status(201).json(row);
    });
  });
});

router.get('/', (req, res) => {
  db.all('SELECT * FROM customers ORDER BY created_at DESC', [], (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

router.get('/:id', (req, res) => {
  db.get('SELECT * FROM customers WHERE id = ?', [req.params.id], (err, row) => {
    if (err) return res.status(500).json({ error: err.message });
    if (!row) return res.status(404).json({ error: 'Cliente não encontrado' });
    res.json(row);
  });
});

router.put('/:id', (req, res) => {
  const { firstName, lastName, email, phone } = req.body;
  const sql = `UPDATE customers SET firstName = ?, lastName = ?, email = ?, phone = ? WHERE id = ?`;
  db.run(sql, [firstName, lastName, email, phone, req.params.id], function (err) {
    if (err) return res.status(500).json({ error: err.message });
    if (this.changes === 0) return res.status(404).json({ error: 'Cliente não encontrado' });
    db.get('SELECT * FROM customers WHERE id = ?', [req.params.id], (err2, row) => {
      if (err2) return res.status(500).json({ error: err2.message });
      res.json(row);
    });
  });
});

router.delete('/:id', (req, res) => {
  db.run('DELETE FROM customers WHERE id = ?', [req.params.id], function (err) {
    if (err) return res.status(500).json({ error: err.message });
    if (this.changes === 0) return res.status(404).json({ error: 'Cliente não encontrado' });
    res.json({ success: true });
  });
});

module.exports = router;