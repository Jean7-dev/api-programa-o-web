require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const db = require('./db');

const app = express();
app.use(cors());
app.use(bodyParser.json());

const initSql = fs.readFileSync(path.join(__dirname, 'sql', 'init.sql'), 'utf8');
db.exec(initSql, (err) => {
  if (err) console.error('Erro inicializando DB:', err);
});

const customersRouter = require('./routes/customers');
app.use('/api/customers', customersRouter);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Backend rodando em http://localhost:${PORT}`));