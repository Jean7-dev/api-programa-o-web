# E-commerce Backend

Backend simples em Node.js + Express + SQLite.

## 🛠️ Como usar

1. Instale as dependências:
```
npm install
```

2. Execute em modo desenvolvimento:
```
npm run dev
```

3. API disponível em:
```
http://localhost:3000/api/clientes
```

## 🧩 Estrutura
- **fonte/rotas** → rotas da API
- **fonte/modelos** → lógica de banco
- **fonte/banco** → banco SQLite
- **público/** → arquivos públicos (caso precise futuramente)
