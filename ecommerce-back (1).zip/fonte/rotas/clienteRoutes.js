const express = require('express');
const router = express.Router();
const Cliente = require('../modelos/clienteModel');

router.get('/', (req, res) => {
  Cliente.listar((err, rows) => {
    if (err) return res.status(500).json({ erro: err.message });
    res.json(rows);
  });
});

router.get('/:id', (req, res) => {
  Cliente.buscar(req.params.id, (err, row) => {
    if (err) return res.status(500).json({ erro: err.message });
    if (!row) return res.status(404).json({ erro: 'Cliente não encontrado' });
    res.json(row);
  });
});

router.post('/', (req, res) => {
  Cliente.criar(req.body, (err, row) => {
    if (err) {
      if (err.message.includes('UNIQUE')) return res.status(409).json({ erro: 'Email já cadastrado' });
      return res.status(500).json({ erro: err.message });
    }
    res.status(201).json(row);
  });
});

router.put('/:id', (req, res) => {
  Cliente.atualizar(req.params.id, req.body, (err, row) => {
    if (err) return res.status(500).json({ erro: err.message });
    if (!row) return res.status(404).json({ erro: 'Cliente não encontrado' });
    res.json(row);
  });
});

router.delete('/:id', (req, res) => {
  Cliente.excluir(req.params.id, (err) => {
    if (err) return res.status(500).json({ erro: err.message });
    res.json({ sucesso: true });
  });
});

module.exports = router;