const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const dbPath = path.resolve(__dirname, '../banco/database.db');
const db = new sqlite3.Database(dbPath);

db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS clientes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    sobrenome TEXT,
    email TEXT NOT NULL UNIQUE,
    telefone TEXT,
    criado_em DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);
});

module.exports = {
  listar(callback) {
    db.all('SELECT * FROM clientes ORDER BY criado_em DESC', [], callback);
  },
  buscar(id, callback) {
    db.get('SELECT * FROM clientes WHERE id = ?', [id], callback);
  },
  criar(data, callback) {
    const { nome, sobrenome, email, telefone } = data;
    db.run(
      'INSERT INTO clientes (nome, sobrenome, email, telefone) VALUES (?, ?, ?, ?)',
      [nome, sobrenome, email, telefone],
      function (err) {
        if (err) return callback(err);
        db.get('SELECT * FROM clientes WHERE id = ?', [this.lastID], callback);
      }
    );
  },
  atualizar(id, data, callback) {
    const { nome, sobrenome, email, telefone } = data;
    db.run(
      'UPDATE clientes SET nome = ?, sobrenome = ?, email = ?, telefone = ? WHERE id = ?',
      [nome, sobrenome, email, telefone, id],
      function (err) {
        if (err) return callback(err);
        db.get('SELECT * FROM clientes WHERE id = ?', [id], callback);
      }
    );
  },
  excluir(id, callback) {
    db.run('DELETE FROM clientes WHERE id = ?', [id], callback);
  }
};